'use client'
import { useState, useCallback, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { formatDate, sportLabel } from '@/lib/utils'
import Link from 'next/link'
import SportBadge from '@/components/SportBadge'

export default function SearchPage() {
  const [term, setTerm] = useState('')
  const [venues, setVenues] = useState([])
  const [teams, setTeams] = useState([])
  const [players, setPlayers] = useState([])
  const [notable, setNotable] = useState([])
  const [games, setGames] = useState([])
  const [searching, setSearching] = useState(false)
  const [searched, setSearched] = useState(false)
  const timer = useRef(null)

  const doSearch = useCallback(async (q) => {
    if (q.length < 2) { setVenues([]); setTeams([]); setPlayers([]); setNotable([]); setGames([]); setSearched(false); return }
    setSearching(true)
    const { data: vn } = await supabase.from('venues').select('id,venue_name,venue_city,sport').or(`venue_name.ilike.%${q}%,venue_city.ilike.%${q}%`).limit(5)
    const { data: tm } = await supabase.from('teams').select('id,team_abbr,full_name,city,sport,primary_color').or(`full_name.ilike.%${q}%,team_name.ilike.%${q}%,team_abbr.ilike.%${q}%,city.ilike.%${q}%`).eq('active', true).limit(5)
    const { data: pl } = await supabase.from('players').select('id,player_name,position,ppg,headshot_url,sport').ilike('player_name', `%${q}%`).order('career_points', { ascending: false }).limit(5)
    const { data: nt } = await supabase.from('notable_games').select('id,title,game_date,sport').ilike('title', `%${q}%`).limit(5)
    const { data: gm } = await supabase.from('games').select('id,game_date,home_team_abbr,away_team_abbr,home_score,away_score,venue,series_info,sport,title').or(`home_team_abbr.ilike.%${q}%,away_team_abbr.ilike.%${q}%,venue.ilike.%${q}%,title.ilike.%${q}%`).gt('home_score', 0).order('game_date', { ascending: false }).limit(15)
    setVenues(vn||[]); setTeams(tm||[]); setPlayers(pl||[]); setNotable(nt||[]); setGames(gm||[])
    setSearching(false); setSearched(true)
  }, [])

  function handleInput(val) { setTerm(val); clearTimeout(timer.current); timer.current = setTimeout(() => doSearch(val), 300) }
  const hasEnt = venues.length+teams.length+players.length+notable.length > 0
  const hasAny = hasEnt || games.length > 0

  return (
    <div>
      <div style={{ padding:'16px 20px', borderBottom:'2px solid var(--rule)' }}>
        <div style={{ fontSize:20, color:'var(--ink)', marginBottom:12 }}>Search</div>
        <input className="search-input" type="text" placeholder="Teams, players, venues, cities, games..." value={term} onChange={e => handleInput(e.target.value)} autoFocus/>
      </div>
      {searching && <div className="loading">Searching...</div>}
      {hasAny && <div style={{ padding:20 }}>
        {venues.length > 0 && <><div className="sec-head">VENUES</div>{venues.map(v => <Link key={v.id} href={`/venue/${v.id}`} className="game-row" style={{ padding:'10px 0', display:'flex', alignItems:'center', gap:10 }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--copper)" strokeWidth="1.5"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>
          <div style={{ flex:1 }}><div style={{ fontSize:15, color:'var(--ink)' }}>{v.venue_name}</div><div className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{v.venue_city} {v.sport ? `\u00B7 ${sportLabel(v.sport)}`:''}</div></div>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--faint)" strokeWidth="1.5"><path d="M9 18l6-6-6-6"/></svg>
        </Link>)}</>}
        {teams.length > 0 && <><div className="sec-head" style={{ marginTop:venues.length?16:0 }}>TEAMS</div>{teams.map(t => <Link key={t.id} href={`/team/${t.id}`} className="game-row" style={{ padding:'10px 0', display:'flex', alignItems:'center', gap:10 }}>
          <div style={{ width:10, height:10, borderRadius:'50%', background:t.primary_color||'var(--dim)', flexShrink:0 }}></div>
          <div style={{ flex:1 }}><div style={{ fontSize:15, color:'var(--ink)' }}>{t.full_name}</div><div className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{sportLabel(t.sport)}</div></div>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--faint)" strokeWidth="1.5"><path d="M9 18l6-6-6-6"/></svg>
        </Link>)}</>}
        {players.length > 0 && <><div className="sec-head" style={{ marginTop:(venues.length||teams.length)?16:0 }}>PLAYERS</div>{players.map(p => <Link key={p.id} href={`/player/${p.id}`} className="game-row" style={{ padding:'10px 0', display:'flex', alignItems:'center', gap:10 }}>
          {p.headshot_url ? <img src={p.headshot_url} alt="" style={{ width:32, height:32, borderRadius:'50%', objectFit:'cover' }}/> : <div style={{ width:32, height:32, borderRadius:'50%', background:'var(--surface)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, color:'var(--dim)', fontFamily:'Arial,sans-serif', fontWeight:700 }}>{p.player_name?.split(' ').map(n=>n[0]).join('')}</div>}
          <div style={{ flex:1 }}><div style={{ fontSize:15, color:'var(--ink)' }}>{p.player_name}</div><div className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{p.position}{p.ppg?` \u00B7 ${p.ppg} PPG`:''}</div></div>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--faint)" strokeWidth="1.5"><path d="M9 18l6-6-6-6"/></svg>
        </Link>)}</>}
        {notable.length > 0 && <><div className="sec-head" style={{ marginTop:16 }}>ALL-TIMERS</div>{notable.map(g => <Link key={g.id} href={`/notable/${g.id}`} className="game-row" style={{ padding:'8px 0', display:'flex', alignItems:'center', gap:8 }}><SportBadge sport={g.sport}/><div style={{ flex:1 }}><div style={{ fontSize:14, color:'var(--ink)' }}>{g.title}</div><div className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{formatDate(g.game_date)}</div></div></Link>)}</>}
        {hasEnt && games.length > 0 && <><hr className="sec-rule" style={{ marginTop:16 }}/><hr className="sec-rule-thin"/></>}
        {games.length > 0 && <><div className="sec-head" style={{ marginTop:hasEnt?14:0 }}>GAMES</div>{games.map(g => <Link key={g.id} href={`/game/${g.id}`} className="game-row" style={{ padding:'10px 0' }}>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}><SportBadge sport={g.sport}/><span style={{ fontSize:14, color:'var(--ink)' }}>{g.sport==='golf'?g.title:`${g.away_team_abbr} ${g.away_score} / ${g.home_score} ${g.home_team_abbr}`}</span></div>
          <div style={{ display:'flex', justifyContent:'space-between', marginTop:3 }}><span className="sans" style={{ fontSize:10, color:'var(--copper)' }}>{g.series_info}</span><span className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{formatDate(g.game_date)}</span></div>
        </Link>)}</>}
      </div>}
      {searched && !searching && !hasAny && <div style={{ padding:40, textAlign:'center', color:'var(--dim)', fontSize:13 }}>No results for &ldquo;{term}&rdquo;</div>}
      {!searched && <div style={{ padding:'40px 20px', textAlign:'center' }}><div style={{ fontSize:15, color:'var(--muted)', marginBottom:8 }}>Find anything in the Raftrs database</div><div className="sans" style={{ fontSize:11, color:'var(--dim)', lineHeight:1.6 }}>Try a city like &ldquo;Denver&rdquo;, a player like &ldquo;LeBron&rdquo;, or a venue like &ldquo;Augusta National&rdquo;</div></div>}
    </div>
  )
}
