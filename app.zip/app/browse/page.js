'use client'
import { useState, useEffect, useCallback } from 'react'
import { supabase } from '@/lib/supabase'
import { formatDate, sportLabel } from '@/lib/utils'
import Link from 'next/link'
import SportBadge from '@/components/SportBadge'

const DECADES = ['1960s','1970s','1980s','1990s','2000s','2010s','2020s']
const ROUNDS_NBA = ['First Round','Conference Semifinals','Conference Finals','NBA Finals']
const ROUNDS_NFL = ['Wild Card','Divisional','Conference Championship','Super Bowl']
const ROUNDS_GOLF = ['Masters','U.S. Open','The Open','PGA Championship']

export default function BrowsePage() {
  const [sport, setSport] = useState('all')
  const [teams, setTeams] = useState([])
  const [venues, setVenues] = useState([])
  const [ats, setAts] = useState([])
  const [players, setPlayers] = useState([])
  const [filters, setFilters] = useState({ team:null, venue:null, decade:null, round:null })
  const [expanded, setExpanded] = useState(null)
  const [filterSearch, setFilterSearch] = useState('')
  const [filteredGames, setFilteredGames] = useState([])
  const [filtering, setFiltering] = useState(false)
  const hasFilters = filters.team||filters.venue||filters.decade||filters.round
  const sv = sport==='all'?null:sport

  useEffect(() => {
    async function ld() {
      let tq = supabase.from('teams').select('id,team_abbr,team_name,full_name,sport,primary_color,championships').eq('active',true).order('team_name')
      if (sv) tq = tq.eq('sport', sv)
      const { data: tm } = await tq; setTeams(tm||[])

      let vq = supabase.from('venues').select('id,venue_name,venue_city,sport').not('description','is',null).order('venue_name')
      if (sv) vq = vq.eq('sport', sv)
      const { data: vn } = await vq; setVenues(vn||[])

      let aq = supabase.from('notable_games').select('id,title,game_date,sport').eq('tier',1).order('game_date',{ascending:false}).limit(12)
      if (sv) aq = aq.eq('sport', sv)
      const { data: at } = await aq; setAts(at||[])

      let pq = supabase.from('players').select('id,player_name,position,ppg,headshot_url,sport').not('ppg','is',null).order('career_points',{ascending:false}).limit(20)
      if (sv) pq = pq.eq('sport', sv)
      const { data: pl } = await pq; setPlayers(pl||[])
    }
    ld(); setFilters({team:null,venue:null,decade:null,round:null}); setFilteredGames([])
  }, [sport, sv])

  const applyFilters = useCallback(async (f) => {
    if (!f.team&&!f.venue&&!f.decade&&!f.round) { setFilteredGames([]); return }
    setFiltering(true)
    let q = supabase.from('games').select('id,game_date,home_team_abbr,away_team_abbr,home_score,away_score,venue,series_info,sport,title').order('game_date',{ascending:false}).limit(50)
    if (sv) q = q.eq('sport', sv)
    if (f.team) q = q.or(`home_team_abbr.eq.${f.team},away_team_abbr.eq.${f.team}`)
    if (f.venue) q = q.eq('venue', f.venue)
    if (f.decade) { const y=parseInt(f.decade); q=q.gte('game_date',`${y}-01-01`).lt('game_date',`${y+10}-01-01`) }
    if (f.round) q = q.ilike('series_info', `%${f.round}%`)
    const { data } = await q; setFilteredGames(data||[]); setFiltering(false)
  }, [sv])

  function setF(k,v) { const n={...filters,[k]:v}; setFilters(n); setExpanded(null); setFilterSearch(''); applyFilters(n) }
  function clearF(k) { const n={...filters,[k]:null}; setFilters(n); applyFilters(n) }
  const roundOpts = sport==='football'?ROUNDS_NFL:sport==='golf'?ROUNDS_GOLF:sport==='basketball'?ROUNDS_NBA:[...ROUNDS_NBA,...ROUNDS_NFL,...ROUNDS_GOLF]

  return (
    <div>
      <div style={{ padding:'16px 20px 0', borderBottom:'2px solid var(--rule)' }}>
        <div style={{ fontSize:20, color:'var(--ink)', marginBottom:12 }}>Browse</div>
        <div style={{ display:'flex' }}>
          {['all','basketball','football','golf'].map(s => {
            const active = sport===s
            return <button key={s} onClick={() => setSport(s)} style={{ flex:1, padding:'10px 0', fontSize:12, fontFamily:'Arial,sans-serif', fontWeight:600, background:'none', border:'none', cursor:'pointer', color:active?'var(--copper)':'var(--dim)', borderBottom:active?'2px solid var(--copper)':'2px solid var(--faint)' }}>{s==='all'?'All':sportLabel(s)}</button>
          })}
        </div>
      </div>

      <div style={{ padding:'10px 20px', borderBottom:'1px solid var(--faint)', display:'flex', gap:6, flexWrap:'wrap', alignItems:'center' }}>
        {[{k:'team',l:'Team'},{k:'venue',l:sport==='golf'?'Course':'Venue'},{k:'decade',l:'Decade'},{k:'round',l:sport==='golf'?'Major':'Round'}].map(f => {
          const v=filters[f.k], isO=expanded===f.k
          return <button key={f.k} onClick={() => setExpanded(isO?null:f.k)} style={{ padding:'6px 12px', fontSize:11, fontFamily:'Arial,sans-serif', fontWeight:600, background:v?'var(--copper)':'var(--card)', color:v?'#fff':'var(--dim)', border:`1px solid ${v?'var(--copper)':'var(--faint)'}`, cursor:'pointer' }}>
            {v||f.l} {v ? <span onClick={e=>{e.stopPropagation();clearF(f.k)}} style={{marginLeft:4,cursor:'pointer'}}>&times;</span> : '\u25BE'}
          </button>
        })}
        {hasFilters && <button onClick={() => {setFilters({team:null,venue:null,decade:null,round:null});setFilteredGames([])}} style={{ padding:'6px 10px', fontSize:10, fontFamily:'Arial,sans-serif', background:'none', border:'none', color:'var(--copper)', cursor:'pointer' }}>Clear all</button>}
      </div>

      {expanded==='team' && <div style={{ padding:'10px 20px', borderBottom:'1px solid var(--faint)', background:'var(--surface)', maxHeight:250, overflowY:'auto' }}>
        <input className="search-input" placeholder="Search teams..." value={filterSearch} onChange={e=>setFilterSearch(e.target.value)} style={{ marginBottom:8, fontSize:12, padding:'8px 12px' }}/>
        {teams.filter(t=>!filterSearch||t.full_name?.toLowerCase().includes(filterSearch.toLowerCase())).map(t =>
          <div key={t.id} onClick={()=>setF('team',t.team_abbr)} style={{ padding:'8px 0', cursor:'pointer', fontSize:13, color:'var(--ink)', borderBottom:'1px solid var(--faint)', display:'flex', alignItems:'center', gap:8 }}>
            <span style={{ width:8, height:8, borderRadius:'50%', background:t.primary_color||'var(--dim)', display:'inline-block' }}></span>{t.full_name}
          </div>)}
      </div>}
      {expanded==='venue' && <div style={{ padding:'10px 20px', borderBottom:'1px solid var(--faint)', background:'var(--surface)', maxHeight:250, overflowY:'auto' }}>
        <input className="search-input" placeholder="Search..." value={filterSearch} onChange={e=>setFilterSearch(e.target.value)} style={{ marginBottom:8, fontSize:12, padding:'8px 12px' }}/>
        {venues.filter(v=>!filterSearch||v.venue_name?.toLowerCase().includes(filterSearch.toLowerCase())).slice(0,30).map(v =>
          <div key={v.id} onClick={()=>setF('venue',v.venue_name)} style={{ padding:'8px 0', cursor:'pointer', fontSize:13, color:'var(--ink)', borderBottom:'1px solid var(--faint)' }}>{v.venue_name} <span className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{v.venue_city}</span></div>)}
      </div>}
      {expanded==='decade' && <div style={{ padding:'10px 20px', borderBottom:'1px solid var(--faint)', background:'var(--surface)', display:'flex', flexWrap:'wrap', gap:6 }}>
        {DECADES.map(d => <div key={d} onClick={()=>setF('decade',d)} style={{ padding:'8px 16px', cursor:'pointer', fontSize:13, background:filters.decade===d?'var(--copper)':'var(--card)', color:filters.decade===d?'#fff':'var(--ink)', border:'1px solid var(--faint)' }}>{d}</div>)}
      </div>}
      {expanded==='round' && <div style={{ padding:'10px 20px', borderBottom:'1px solid var(--faint)', background:'var(--surface)' }}>
        {roundOpts.map(r => <div key={r} onClick={()=>setF('round',r)} style={{ padding:'8px 0', cursor:'pointer', fontSize:13, color:'var(--ink)', borderBottom:'1px solid var(--faint)' }}>{r}</div>)}
      </div>}

      {hasFilters && <div style={{ padding:20 }}>
        {filtering ? <div className="loading">Loading...</div> : <>
          <div className="sec-head">{filteredGames.length} GAME{filteredGames.length!==1?'S':''}</div>
          {filteredGames.map(g => <Link key={g.id} href={`/game/${g.id}`} className="game-row" style={{ padding:'10px 0' }}>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}><SportBadge sport={g.sport}/><span style={{ fontSize:14, color:'var(--ink)' }}>{g.sport==='golf'?g.title:`${g.away_team_abbr} ${g.away_score} / ${g.home_score} ${g.home_team_abbr}`}</span></div>
            <div style={{ display:'flex', justifyContent:'space-between', marginTop:3 }}><span className="sans" style={{ fontSize:10, color:'var(--copper)' }}>{g.series_info}</span><span className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{formatDate(g.game_date)}</span></div>
          </Link>)}
          {filteredGames.length===0 && <div style={{ fontSize:13, color:'var(--dim)', padding:'20px 0' }}>No games match these filters</div>}
        </>}
      </div>}

      {!hasFilters && <div style={{ padding:20 }}>
        {teams.length > 0 && <><div className="sec-head">TEAMS</div><div className="team-grid">{teams.map(t => <Link key={t.id} href={`/team/${t.id}`} className="team-chip" style={{ borderLeftColor:t.primary_color||'var(--faint)' }}>{t.team_abbr}</Link>)}</div></>}
        {venues.length > 0 && <><div className="sec-head" style={{ marginTop:24 }}>{sport==='golf'?'COURSES':'VENUES'}</div><div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{venues.slice(0,20).map(v => <Link key={v.id} href={`/venue/${v.id}`} style={{ padding:'6px 12px', fontSize:11, fontFamily:'Arial,sans-serif', background:'var(--card)', border:'1px solid var(--faint)', color:'var(--ink)', textDecoration:'none' }}>{v.venue_name}</Link>)}</div></>}
        {ats.length > 0 && <><div className="sec-head" style={{ marginTop:24 }}>ALL-TIMERS</div>{ats.slice(0,6).map(g => <Link key={g.id} href={`/notable/${g.id}`} className="game-row" style={{ padding:'8px 0' }}><div style={{ display:'flex', alignItems:'center', gap:8 }}><SportBadge sport={g.sport}/><span style={{ fontSize:13, color:'var(--ink)' }}>{g.title}</span></div><div className="sans" style={{ fontSize:10, color:'var(--dim)', marginTop:2, marginLeft:44 }}>{formatDate(g.game_date)}</div></Link>)}</>}
        {players.length > 0 && <><div className="sec-head" style={{ marginTop:24 }}>PLAYERS</div><div className="perf-scroll">{players.slice(0,10).map(p => <Link key={p.id} href={`/player/${p.id}`} className="perf-card" style={{ width:130 }}>
          {p.headshot_url && <img src={p.headshot_url} alt="" style={{ width:36, height:36, borderRadius:'50%', objectFit:'cover', marginBottom:6 }}/>}
          <div className="perf-name">{p.player_name}</div><div className="perf-sub">{p.position}{p.ppg?` \u00B7 ${p.ppg} PPG`:''}</div>
        </Link>)}</div></>}
      </div>}
    </div>
  )
}
