'use client'
import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import { formatDate } from '@/lib/utils'
import BackButton from '@/components/BackButton'

export default function PlayerPage() {
  const { id } = useParams()
  const [player, setPlayer] = useState(null)
  const [gameLog, setGameLog] = useState([])
  const [allTimers, setAllTimers] = useState([])
  const [playoffAvg, setPlayoffAvg] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      const { data: p } = await supabase.from('players').select('*').eq('id', id).single()
      if (!p) { setLoading(false); return }
      setPlayer(p)
      const isNBA = p.sport === 'basketball' || !p.sport

      if (isNBA) {
        // Get box score appearances - KEY FIX: uses nba_game_id
        const { data: bs } = await supabase.from('box_scores').select('nba_game_id,points,rebounds,assists,minutes,steals,blocks')
          .eq('player_name', p.player_name).order('nba_game_id', { ascending: false }).limit(50)
        if (bs?.length) {
          const tot = bs.reduce((a, b) => ({ pts:a.pts+(b.points||0), reb:a.reb+(b.rebounds||0), ast:a.ast+(b.assists||0), gp:a.gp+1 }), { pts:0, reb:0, ast:0, gp:0 })
          setPlayoffAvg({ ppg:(tot.pts/tot.gp).toFixed(1), rpg:(tot.reb/tot.gp).toFixed(1), apg:(tot.ast/tot.gp).toFixed(1), gp:tot.gp })

          // Get game details via nba_game_id
          const espnIds = [...new Set(bs.map(b => b.nba_game_id))]
          const { data: games } = await supabase.from('games').select('id,nba_game_id,game_date,home_team_abbr,away_team_abbr,home_score,away_score,series_info')
            .in('nba_game_id', espnIds).order('game_date', { ascending: false })
          if (games) {
            setGameLog(games.map(g => ({ ...g, stats: bs.find(b => b.nba_game_id === g.nba_game_id) })))

            // All-Timers: find notable games linked to games this player appeared in
            const gameIds = games.map(g => g.id)
            const { data: at } = await supabase.from('notable_games').select('id,title,game_date,sport')
              .in('game_id', gameIds).order('game_date', { ascending: false })
            setAllTimers(at || [])
          }
        }
      }
      setLoading(false)
    }
    load()
  }, [id])

  if (loading) return <div className="loading">Loading...</div>
  if (!player) return <div className="empty">Player not found</div>
  const isNBA = player.sport === 'basketball' || !player.sport

  return (
    <div>
      <BackButton />
      <div style={{ padding:20, borderBottom:'2px solid var(--rule)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:16 }}>
          {player.headshot_url ? <img src={player.headshot_url} alt="" style={{ width:72, height:72, borderRadius:'50%', objectFit:'cover', border:'2px solid var(--faint)' }}/> :
          <div style={{ width:72, height:72, borderRadius:'50%', background:'var(--copper)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:22, fontFamily:'Arial,sans-serif', fontWeight:700 }}>{(player.first_name?.[0]||'')+(player.last_name?.[0]||'')}</div>}
          <div>
            <div style={{ fontSize:24, color:'var(--ink)', lineHeight:1.2 }}>{player.player_name}</div>
            <div className="sans" style={{ fontSize:11, color:'var(--dim)', marginTop:4 }}>{[player.position, player.height, player.experience].filter(Boolean).join(' \u00B7 ')}</div>
            {player.draft_info && <div className="sans" style={{ fontSize:10, color:'var(--dim)', marginTop:2 }}>{player.draft_info}</div>}
            <div style={{ marginTop:6 }}>
              <span className="sans" style={{ fontSize:10, fontWeight:600, letterSpacing:1, padding:'3px 8px', background:player.active?'rgba(181,86,58,0.08)':'var(--surface)', color:player.active?'var(--copper)':'var(--dim)', border:`1px solid ${player.active?'var(--copper)':'var(--faint)'}` }}>{player.active?'ACTIVE':'RETIRED'}</span>
              {player.debut_year && <span className="sans" style={{ fontSize:10, color:'var(--dim)', marginLeft:8 }}>Since {player.debut_year}</span>}
            </div>
          </div>
        </div>
      </div>
      <div style={{ borderBottom:'1px solid var(--rule)' }}></div>

      {isNBA && player.games_played && (<div style={{ padding:'14px 20px', borderBottom:'1px solid var(--faint)' }}>
        <div className="sans" style={{ fontSize:9, color:'var(--dim)', letterSpacing:2, fontWeight:600, marginBottom:10 }}>CAREER STATS</div>
        <div style={{ display:'flex' }}>
          {[{v:player.ppg,l:'PPG'},{v:player.rpg,l:'RPG'},{v:player.apg,l:'APG'},{v:player.spg,l:'SPG'},{v:player.fg_pct?`${player.fg_pct}%`:null,l:'FG%'}].filter(s=>s.v!=null).map((s,i,a) =>
            <div key={i} style={{ flex:1, textAlign:'center', borderRight:i<a.length-1?'1px solid var(--faint)':'none' }}><div style={{ fontSize:20, color:'var(--ink)' }}>{s.v}</div><div className="sans" style={{ fontSize:9, color:'var(--dim)', letterSpacing:1, fontWeight:600, marginTop:2 }}>{s.l}</div></div>
          )}
        </div>
        <div style={{ display:'flex', gap:16, marginTop:12, paddingTop:10, borderTop:'1px solid var(--faint)' }}>
          {[{v:player.games_played?.toLocaleString(),l:'Games'},{v:player.career_points?.toLocaleString(),l:'Points'},{v:player.career_rebounds?.toLocaleString(),l:'Rebounds'},{v:player.career_assists?.toLocaleString(),l:'Assists'}].filter(s=>s.v).map((s,i) =>
            <div key={i}><div style={{ fontSize:13, color:'var(--ink)' }}>{s.v}</div><div className="sans" style={{ fontSize:9, color:'var(--dim)', marginTop:1 }}>{s.l}</div></div>
          )}
        </div>
      </div>)}

      {playoffAvg && (<div style={{ padding:'14px 20px', borderBottom:'1px solid var(--faint)' }}>
        <div className="sans" style={{ fontSize:9, color:'var(--dim)', letterSpacing:2, fontWeight:600, marginBottom:10 }}>PLAYOFF STATS ({playoffAvg.gp} games)</div>
        <div style={{ display:'flex' }}>
          {[{v:playoffAvg.ppg,l:'PPG'},{v:playoffAvg.rpg,l:'RPG'},{v:playoffAvg.apg,l:'APG'}].map((s,i,a) =>
            <div key={i} style={{ flex:1, textAlign:'center', borderRight:i<a.length-1?'1px solid var(--faint)':'none' }}><div style={{ fontSize:20, color:'var(--ink)' }}>{s.v}</div><div className="sans" style={{ fontSize:9, color:'var(--dim)', letterSpacing:1, fontWeight:600, marginTop:2 }}>{s.l}</div></div>
          )}
        </div>
      </div>)}

      {allTimers.length > 0 && (<><hr className="sec-rule"/><hr className="sec-rule-thin"/><div style={{ padding:20 }}>
        <div className="sec-head">ALL-TIMERS</div>
        {allTimers.map(g => <Link key={g.id} href={`/notable/${g.id}`} className="game-row" style={{ padding:'8px 0' }}>
          <span className="at-badge-sm" style={{ marginRight:8 }}>&#9733; ALL-TIMER</span>
          <span style={{ fontSize:13, color:'var(--ink)' }}>{g.title}</span>
          <div className="sans" style={{ fontSize:10, color:'var(--dim)', marginTop:2 }}>{formatDate(g.game_date)}</div>
        </Link>)}
      </div></>)}

      {gameLog.length > 0 && (<><hr className="sec-rule"/><hr className="sec-rule-thin"/><div style={{ padding:20 }}>
        <div className="sec-head">PLAYOFF GAMES ({gameLog.length})</div>
        {gameLog.map(g => <Link key={g.id} href={`/game/${g.id}`} className="game-row" style={{ padding:'10px 0' }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
            <span style={{ fontSize:14, color:'var(--ink)' }}>{g.away_team_abbr} {g.away_score} / {g.home_score} {g.home_team_abbr}</span>
            <span className="sans" style={{ fontSize:10, color:'var(--dim)' }}>{formatDate(g.game_date)}</span>
          </div>
          {g.series_info && <div className="sans" style={{ fontSize:10, color:'var(--copper)', marginTop:2 }}>{g.series_info}</div>}
          {g.stats && <div className="sans" style={{ fontSize:11, color:'var(--muted)', marginTop:4 }}>{g.stats.points} pts &middot; {g.stats.rebounds} reb &middot; {g.stats.assists} ast{g.stats.steals?` \u00B7 ${g.stats.steals} stl`:''}{g.stats.blocks?` \u00B7 ${g.stats.blocks} blk`:''}</div>}
        </Link>)}
      </div></>)}

      <hr className="sec-rule"/><hr className="sec-rule-thin"/>
      <div style={{ padding:20 }}>
        <div className="sec-head">REFLECTIONS</div>
        <div style={{ fontSize:13, color:'var(--muted)', marginBottom:12, lineHeight:1.6 }}>What does {player.first_name || player.player_name} mean to you as a fan?</div>
        <textarea className="story-textarea" placeholder={`Share a memory about ${player.first_name || player.player_name}...`}/>
      </div>
      <div style={{ padding:'0 20px 20px' }}>
        <div className="sec-head">ENCOUNTERS</div>
        <div style={{ fontSize:13, color:'var(--muted)', marginBottom:12, lineHeight:1.6 }}>Ever meet {player.first_name || player.player_name}? Share the story.</div>
        <textarea className="story-textarea" placeholder="Where did you cross paths?"/>
      </div>
      <div style={{ height:80 }}></div>
    </div>
  )
}
